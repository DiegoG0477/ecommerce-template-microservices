// apps/cart-service/src/modules/cart/cart.service.ts
import { Injectable, NotFoundException, InternalServerErrorException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, EntityManager } from 'typeorm';
import { v4 as uuidv4 } from 'uuid'; // Para generar UUIDs si es necesario

import { Cart } from './entities/cart.entity';
import { CartItem } from './entities/cart-item.entity';
import { AddToCartDto } from './dto/add-to-cart.dto';
import { UserPayload } from './interfaces/user-payload.interface';
import { CartResponseDto } from './dto/cart-response.dto'; // Ajusta el nombre si es necesario
import { CartItemResponseDto } from './dto/cart-item-response.dto';

@Injectable()
export class CartService {
  constructor(
    // Aunque uses procedimientos almacenados, inyectar el EntityManager
    // es la forma estándar de ejecutar queries crudas o llamar a SPs.
    // Si necesitas operaciones CRUD directas con entidades, inyectarías
    // @InjectRepository(Cart) private cartRepository: Repository<Cart>,
    // @InjectRepository(CartItem) private cartItemRepository: Repository<CartItem>,
    private readonly entityManager: EntityManager,
  ) {}

  async getCart(user: UserPayload): Promise<CartResponseDto> {
    const { userId } = user;

    try {
      // El procedimiento GetCartWithTotal devuelve dos result sets.
      // Primero los items, luego el total.
      const results = await this.entityManager.query('CALL GetCartWithTotal(?)', [userId]);

      if (!results || results.length < 2 || !results[0] || !results[1] || results[1].length === 0) {
        // Si no hay carrito o está vacío, el SP podría no devolver el segundo result set o estar vacío
        // Devolvemos un carrito vacío o un NotFoundException según la lógica del SP.
        // Vamos a asumir que si `results[1]` está vacío o no existe, no hay carrito.
        // O podría ser que el SP `GetOrCreateCart` dentro de `GetCartWithTotal` haya creado uno vacío.
        // Necesitamos ser consistentes. Si el SP crea un carrito vacío, no es un "Not Found".

        // Reintentar obtener el carrito ID por si acaso fue creado pero está vacío
        const cartIdResult = await this.entityManager.query('CALL GetOrCreateCart(?)', [userId]);
        if(!cartIdResult || cartIdResult.length === 0 || !cartIdResult[0].id) {
            throw new NotFoundException(`Cart not found for user ${userId} and could not be created.`);
        }

        return {
          id: cartIdResult[0].id,
          userId: userId,
          items: [],
          totalItems: 0,
          totalQuantity: 0,
          totalAmount: 0,
        };
      }

      const cartItemsRaw: any[] = results[0]; // Primer result set: items
      const cartTotalRaw: any = results[1][0];   // Segundo result set: totales (debería ser un array con un objeto)

      const itemsDto: CartItemResponseDto[] = cartItemsRaw.map(item => ({
        id: item.id,
        productId: item.product_id,
        productName: item.product_name,
        quantity: parseInt(item.quantity, 10),
        price: parseFloat(item.price),
        lineTotal: parseFloat(item.line_total),
      }));

      return {
        id: cartTotalRaw.cart_id,
        userId: userId, // El SP GetCartWithTotal no devuelve userId, lo tomamos del payload
        items: itemsDto,
        totalItems: parseInt(cartTotalRaw.total_items, 10),
        totalQuantity: itemsDto.reduce((sum, item) => sum + item.quantity, 0), // El SP GetCartWithTotal no provee total_quantity
        totalAmount: parseFloat(cartTotalRaw.total_amount),
      };

    } catch (error) {
      console.error(`Error in getCart for user ${userId}:`, error);
      throw new InternalServerErrorException('Could not retrieve cart.');
    }
  }

  async addItemToCart(user: UserPayload, addToCartDto: AddToCartDto): Promise<{ message: string; itemId?: string; cartId: string }> {
    const { userId } = user;
    const { productId, quantity, price, productName } = addToCartDto;

    try {
      // El procedimiento AddToCart llama internamente a GetOrCreateCart
      const result = await this.entityManager.query(
        'CALL AddToCart(?, ?, ?, ?, ?)',
        [userId, productId, quantity, price, productName || null], // productName es opcional
      );

      if (!result || result.length === 0 || !result[0].message) {
        throw new InternalServerErrorException('Failed to add item to cart, unexpected SP result.');
      }

      // El SP AddToCart devuelve un mensaje y opcionalmente item_id
      // También necesitamos el cartId. Podemos obtenerlo llamando a GetOrCreateCart de nuevo
      // o modificando AddToCart para que devuelva también el cart_id.
      // Por simplicidad aquí, lo obtenemos de nuevo (aunque menos eficiente).
      const cartIdResult = await this.entityManager.query('CALL GetOrCreateCart(?)', [userId]);
      if(!cartIdResult || cartIdResult.length === 0 || !cartIdResult[0].id) {
          throw new InternalServerErrorException('Could not determine cart ID after adding item.');
      }

      return {
        message: result[0].message,
        itemId: result[0].item_id, // Puede ser undefined si actualiza cantidad
        cartId: cartIdResult[0].id,
      };
    } catch (error) {
      console.error(`Error in addItemToCart for user ${userId}, product ${productId}:`, error);
      if (error instanceof BadRequestException || error instanceof NotFoundException) {
        throw error;
      }
      throw new InternalServerErrorException('Could not add item to cart.');
    }
  }

  async removeItemFromCart(user: UserPayload, productId: string): Promise<{ message: string }> {
    const { userId } = user;

    if (!productId) {
        throw new BadRequestException('Product ID is required.');
    }

    try {
      const result = await this.entityManager.query('CALL RemoveFromCart(?, ?)', [userId, productId]);
      if (!result || result.length === 0 || !result[0].message) {
        throw new InternalServerErrorException('Failed to remove item from cart, unexpected SP result.');
      }
      return { message: result[0].message };
    } catch (error) {
      console.error(`Error in removeItemFromCart for user ${userId}, product ${productId}:`, error);
      throw new InternalServerErrorException('Could not remove item from cart.');
    }
  }

  async clearCart(user: UserPayload): Promise<{ message: string }> {
    const { userId } = user;
    try {
      const result = await this.entityManager.query('CALL ClearCart(?)', [userId]);
      if (!result || result.length === 0 || !result[0].message) {
        throw new InternalServerErrorException('Failed to clear cart, unexpected SP result.');
      }
      return { message: result[0].message };
    } catch (error) {
      console.error(`Error in clearCart for user ${userId}:`, error);
      throw new InternalServerErrorException('Could not clear cart.');
    }
  }

  // Opcional: Si quieres usar TypeORM directamente en lugar de SP para algunas cosas:
  // async getCartUsingTypeORM(userId: string): Promise<Cart | null> {
  //   return this.cartRepository.findOne({
  //     where: { userId },
  //     relations: ['items'], // Carga los items relacionados
  //   });
  // }

  // async createCartUsingTypeORM(userId: string): Promise<Cart> {
  //   const newCart = this.cartRepository.create({ id: uuidv4(), userId });
  //   return this.cartRepository.save(newCart);
  // }
}