// apps/cart-service/src/modules/cart/interfaces/user-payload.interface.ts
export interface UserPayload {
    userId: string;
    // Podrías añadir más campos si el gateway los pasa y son útiles aquí
    // email?: string;
    // roles?: string[];
}