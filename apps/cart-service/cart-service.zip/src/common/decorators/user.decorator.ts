// apps/cart-service/src/common/decorators/user.decorator.ts

import { createParamDecorator, ExecutionContext } from '@nestjs/common';
// Importamos la interfaz que define la estructura del payload del usuario.
// Esta interfaz debería estar en un lugar accesible, por ejemplo, dentro del módulo 'cart'
// si es específica para cómo 'cart' espera el payload, o en 'libs/common/interfaces'
// si es una estructura de payload de usuario estándar en todo tu sistema.
// Por ahora, asumamos que está en el módulo cart, ya que la definimos allí antes.
import { UserPayload } from '../../modules/cart/interfaces/user-payload.interface';

/**
 * @User() Decorator
 *
 * Este decorador de parámetro personalizado se utiliza para extraer el objeto `user`
 * (que contiene el payload del JWT decodificado, como `userId`, `email`, `roles`)
 * del objeto `request` de Express.
 *
 * Se asume que un guard de autenticación (ej. JwtAuthGuard) se ha ejecutado previamente
 * y ha adjuntado el payload del usuario a `request.user`.
 *
 * Uso en un controlador:
 * ```typescript
 * @Get()
 * async findCart(@User() user: UserPayload) {
 *   console.log(user.userId);
 *   // ...
 * }
 * ```
 *
 * @param data - Datos opcionales pasados al decorador (no se usan en este caso).
 * @param ctx - El ExecutionContext, que proporciona acceso al request actual.
 * @returns El objeto UserPayload adjunto al request, o undefined si no existe.
 */
export const User = createParamDecorator(
  (data: unknown, ctx: ExecutionContext): UserPayload => {
    // 1. ctx.switchToHttp() obtiene el contexto HTTP de la solicitud actual.
    //    Esto es necesario porque NestJS es agnóstico a la plataforma (HTTP, WebSockets, gRPC).
    const request = ctx.switchToHttp().getRequest();

    // 2. Retornamos request.user.
    //    La convención estándar, especialmente cuando se usa Passport.js (que alimenta
    //    @nestjs/passport), es que el guard de autenticación (como JwtAuthGuard)
    //    adjunte el usuario autenticado (o su payload decodificado) a `request.user`.
    //    Si tu API Gateway pasa el userId en un header, este decorador necesitaría
    //    modificarse para leer ese header en lugar de `request.user`.
    return request.user;
  },
);